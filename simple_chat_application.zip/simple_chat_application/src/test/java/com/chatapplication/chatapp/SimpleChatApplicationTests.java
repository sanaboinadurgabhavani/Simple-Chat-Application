package com.chatapplication.chatapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
